#pragma once
int setShader(char* shaderType, char* shaderFile);

